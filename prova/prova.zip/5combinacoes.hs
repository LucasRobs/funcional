heTriangulo' ((antes,  depois), res) index 
  | (antes + depois) > index && res = ((index , antes), True)
  | otherwise = ((antes,  depois), False)

heTriangulo (a, b, c) = foldl heTriangulo' ((c, b), True) [a, b, c] 

ehCombinacao' ((array, index), res) value 
  |  index > (length array - 3) = ((array, (index + 1)), res)
  | snd $ heTriangulo sequencia = ((array, (index + 1)), res ++ [sequencia])
  | otherwise = ((array, (index + 1)), res)
  where sequencia = (value, (array !! (index + 1)), (array !! (index + 2)))

ehCombinacao array = foldl ehCombinacao' ((array, 0), []) array

main = do
  array <- readLn :: IO [Int]
  print $ snd $ ehCombinacao array

